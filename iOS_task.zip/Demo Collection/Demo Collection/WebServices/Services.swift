//
//  Services.swift
//  Demo Collection
//
//  Created by InventCoLabsAmit on 14/07/21.
//

import Foundation



let imageCache = NSCache<NSString, NSData>()


class RestApi: NSObject , URLSessionDelegate {

typealias CompletionBlock = (_ result: Array<Any>) -> Void
typealias FailureBlock = (_ error: Error) -> Void

class func restApiCalling(completionHandler : @escaping CompletionBlock, failure : @escaping FailureBlock) -> Void {
    
    
    var request : URLRequest?
    var session : URLSession?
    
    request = URLRequest(url: URL(string: ApiUrl)!)
    
    
    request?.httpMethod = "GET"
    
    
    
    let configuration = URLSessionConfiguration.default
    
    configuration.timeoutIntervalForRequest = 0
    configuration.timeoutIntervalForResource = 0
    
    session = URLSession(configuration: configuration)
    
    
    
    print("Headers:--",request?.allHTTPHeaderFields)
    request?.addValue("application/json", forHTTPHeaderField: "Content-Type")
    
    
    
    session?.dataTask(with: request! as URLRequest) { data, response, error in
        
        
        
        DispatchQueue.main.async {
            print(request)
            
            guard let dataeResult = data,
                  let response = response as? HTTPURLResponse,
                  (200 ..< 423) ~= response.statusCode,
                  error == nil else {
                return
            }
            
            
            
            if(error != nil)
            {
                failure(error as! Error)
            }
            else
            {
                if let resp = data{
                    do {
                        
                        let json = try JSONSerialization.jsonObject(with: resp) as! Array<Any>
                        
                        print(json)
                        
                        completionHandler(json)
                    }catch{
                        failure(error as! Error)
                    }
                    
                }else{
                    failure(error as! Error)
                }
            }
            
        }
    }
    
    .resume()
    
    
    
    
    
    
}

func downloadImage(_ url: String,  completion: @escaping (Data?, Error?) -> Void) {
    
    if let urlStr = URL(string: url) {
        if let cachedImage = imageCache.object(forKey: urlStr.absoluteString as NSString) {
            let data : Data  = cachedImage as Data
            completion(data, nil)
        }else{
            
            
            let request = URLRequest(url: urlStr)
            let configuration = URLSessionConfiguration.default
            let session = URLSession(configuration: configuration, delegate: self, delegateQueue:OperationQueue.main)
            
            let task = session.dataTask(with: request) { data, response, error in
                guard let data = data,
                      let response = response as? HTTPURLResponse,
                      (200 ..< 300) ~= response.statusCode,
                      error == nil else {
                    completion(nil, error)
                    return
                }
                
                imageCache.setObject(data as NSData, forKey: urlStr.absoluteString as NSString)
                completion(data, nil)
            }
            task.resume()
        }
    }
}
}
