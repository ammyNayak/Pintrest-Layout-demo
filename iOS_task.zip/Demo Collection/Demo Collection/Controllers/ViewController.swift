//
//  ViewController.swift
//  Demo Collection
//
//  Created by InventCoLabsAmit on 13/07/21.
//

import UIKit



class ViewController: UIViewController {
    
    //MARK:- IBoutlets
    
    @IBOutlet weak var colHome: UICollectionView!
    @IBOutlet weak var catgCol: UICollectionView!
    
    //MARK:- IBoutlets
    var isLoad:Bool = false
    var catgAr = ["Trending Now","New in 2021","Tiktok","Most Popular","New Arrival"]
    var resp = [homeData]()
    
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        api()
    }
    
    //MARK:- WebServices
    func api(){
        activityIndicator("Loading..")
        RestApi.restApiCalling { dict in
            
            DispatchQueue.main.async {
                for i in dict{
                    let data = homeData.init(dict: i as! [String:Any])
                    self.resp.append(data)

                }
                
                
                if let layout = self.colHome?.collectionViewLayout as? CustomLayout {
                    layout.delegate = self
                    
                    
                }
                self.isLoad = true
                self.colHome.reloadData()
                effectView.removeFromSuperview()
            }
            
        } failure: { error in
            
        }
        
    }
    //MARK:- Actions
    @objc func addToFav(sender:UIButton){
        if  resp[sender.tag].isFav == true{
            resp[sender.tag].isFav = false
        }else{
            resp[sender.tag].isFav = true
        }
        
        self.colHome.reloadItems(at: [IndexPath(row: sender.tag, section: 0)])
    }
    
}

extension ViewController: UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate{
    //MARK:- Collection Deleagtes
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == colHome{
            return resp.count
        }else{
            return 4
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView ==  catgCol{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! categoryCollectionCell
            cell.lbl.text = catgAr[indexPath.item]
            cell.backVw.clipsToBounds = true
            cell.backVw.layer.borderWidth = 1
            cell.backVw.layer.borderColor = UIColor.darkGray.cgColor
            return cell
        }else{
            if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as? CustomCollectionViewCell{
                
                let dict  = resp[indexPath.item]
                let urlImage = dict.image ?? ""
                RestApi().downloadImage(urlImage) { (dataImage, error) in
                    if error == nil, let dataImg = dataImage {
                        
                        
                        cell.image.image = UIImage(data: dataImg)
                        
                    }
                }
                if dict.isFav == false{
                    cell.favBtn.setImage(UIImage(systemName: "heart"), for: .normal)
                }else{
                    cell.favBtn.setImage(UIImage(systemName: "heart.fill"), for: .normal)
                }
                cell.clipsToBounds =  true
                cell.image.layer.cornerRadius =  20
                cell.image.layer.shadowColor = UIColor.lightGray.cgColor
                
                cell.image.contentMode = .scaleAspectFill
                
                cell.productName.text = dict.title ?? ""
                cell.priceLbl.text = "$\(dict.price ?? 0.0)"
                let attributes: [NSAttributedString.Key : Any] = [
                                                                .strikethroughColor: UIColor.red,
                                                                  .foregroundColor: UIColor.black]
                let attributeString = NSMutableAttributedString(string: "$\(dict.price ?? 0.0)",attributes: attributes)
                attributeString.addAttribute(
                    NSAttributedString.Key.strikethroughStyle,
                    value: 1,
                    range: NSRange(location: 0, length: attributeString.length))
                cell.strikeAmountLbl.attributedText = attributeString
                cell.favBtn.tag = indexPath.item
                cell.favBtn.addTarget(self, action: #selector(addToFav(sender:)), for: .touchUpInside)
                return cell
            }
        }
        
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == catgCol{
            if let cell = collectionView.cellForItem(at: indexPath) as? categoryCollectionCell{
                cell.backVw.backgroundColor = .black
                cell.lbl.textColor = .white
            }
            
        }
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if collectionView == catgCol{
            if let cell = collectionView.cellForItem(at: indexPath) as? categoryCollectionCell{
                cell.backVw.backgroundColor = .white
                cell.lbl.textColor = .darkGray
            }
            
        }
    }
}

extension ViewController: CustomLayoutDelegate {
    //MARK:- Custom Layout Delegate
    func collectionView(
        _ collectionView: UICollectionView,
        heightForPhotoAtIndexPath indexPath:IndexPath) -> CGFloat {
        
        
        let size = arc4random_uniform(5) + 2
        return CGFloat(size * 100)
       
        
        
    }
}



















