//
//  Constants.swift
//  Demo Collection
//
//  Created by InventCoLabsAmit on 14/07/21.
//

import Foundation


let ApiUrl =  "https://fakestoreapi.com/products"
