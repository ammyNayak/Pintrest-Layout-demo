//
//  DashBoardModel.swift
//  Demo Collection
//
//  Created by InventCoLabsAmit on 14/07/21.
//

import Foundation

struct homeData: Codable {
    
    var id : Int?
    var image : String?
    var price : Double?
    var title : String?
    var isFav : Bool = false
  
    init(dict: [String:Any]) {
        
        id = dict["id"] as? Int
        image = dict["image"] as? String
        price = dict["price"] as? Double
        title = dict["title"] as? String
        
        
        
    }
    
}
