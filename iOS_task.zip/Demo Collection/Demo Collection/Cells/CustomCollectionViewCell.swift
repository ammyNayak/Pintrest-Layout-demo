//
//  CustomCollectionViewCell.swift
//  Demo Collection
//
//  Created by InventCoLabsAmit on 14/07/21.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var strikeAmountLbl: UILabel!
    
    @IBOutlet weak var favBtn: UIButton!
    override  func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
}


