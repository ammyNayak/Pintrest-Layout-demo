//
//  CategoryCell.swift
//  Demo Collection
//
//  Created by InventCoLabsAmit on 14/07/21.
//

import Foundation
import UIKit

class categoryCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var backVw: UIView!
    @IBOutlet weak var lbl: UILabel!
    
    
    override  func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
